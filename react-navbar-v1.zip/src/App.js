import React from 'react';
import Navbar from "./components/Navbar/Navbar";
import './App.css';

function App() {
  return (
    <div className="App">
      <Navbar />
      <br/>
      <h1> Higiene y Seguridad: Elementos de Proteccion Personal </h1>
      <div>
        <br/>
            <p> Somos proveedores de elementos de seguiridad laboral. Contactanos para solicitar cotizacion. </p>
      </div>     

       
    </div>
  );
}

export default App;
